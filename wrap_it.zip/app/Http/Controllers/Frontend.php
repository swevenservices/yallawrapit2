<?php

namespace App\Http\Controllers;

use App\Models\Project;
use Illuminate\Http\Request;

class Frontend extends Controller
{

     public function index()
    {
        $projects =  Project::with('media')->latest()->take(2)->get();
        return  view ('front-end.index' ,compact('projects'));
    }
    public function about()
    {
        return  view ('front-end.about');
    }
    public function contact()
    {
        return view('front-end.contact');
    }
    public function services(){
        return  view ('front-end.projects');
    }
    public function projects(){
          $projects =  Project::with('media')->paginate(20);
          return  view ('front-end.projects' ,compact('projects'));
    }
}
