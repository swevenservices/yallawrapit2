<form wire:submit.prevent="submit" class="pt-3">

    <div class="form-group <?php echo e($errors->has('project.title') ? 'invalid' : ''); ?>">
        <label class="form-label required" for="title"><?php echo e(trans('cruds.project.fields.title')); ?></label>
        <input class="form-control" type="text" name="title" id="title" required wire:model.defer="project.title">
        <div class="validation-message">
            <?php echo e($errors->first('project.title')); ?>

        </div>
        <div class="help-block">
            <?php echo e(trans('cruds.project.fields.title_helper')); ?>

        </div>
    </div>
    <div class="form-group <?php echo e($errors->has('project.excerpt') ? 'invalid' : ''); ?>">
        <label class="form-label required" for="excerpt"><?php echo e(trans('cruds.project.fields.excerpt')); ?></label>
        <textarea class="form-control" name="excerpt" id="excerpt" required wire:model.defer="project.excerpt" rows="4"></textarea>
        <div class="validation-message">
            <?php echo e($errors->first('project.excerpt')); ?>

        </div>
        <div class="help-block">
            <?php echo e(trans('cruds.project.fields.excerpt_helper')); ?>

        </div>
    </div>
    <div class="form-group <?php echo e($errors->has('project.slug') ? 'invalid' : ''); ?>">
        <label class="form-label required" for="slug"><?php echo e(trans('cruds.project.fields.slug')); ?></label>
        <input class="form-control" type="text" name="slug" id="slug" required wire:model.defer="project.slug">
        <div class="validation-message">
            <?php echo e($errors->first('project.slug')); ?>

        </div>
        <div class="help-block">
            <?php echo e(trans('cruds.project.fields.slug_helper')); ?>

        </div>
    </div>
    <div class="form-group <?php echo e($errors->has('mediaCollections.project_before_image') ? 'invalid' : ''); ?>">
        <label class="form-label" for="before_image"><?php echo e(trans('cruds.project.fields.before_image')); ?></label>
        <?php if (isset($component)) { $__componentOriginal8445cfed575af5f8fe9105ababf279bed224606c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Dropzone::class, []); ?>
<?php $component->withName('dropzone'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['id' => 'before_image','name' => 'before_image','action' => ''.e(route('admin.projects.storeMedia')).'','collection-name' => 'project_before_image','max-file-size' => '1','max-width' => '1920','max-height' => '1080','max-files' => '1']); ?>
<?php if (isset($__componentOriginal8445cfed575af5f8fe9105ababf279bed224606c)): ?>
<?php $component = $__componentOriginal8445cfed575af5f8fe9105ababf279bed224606c; ?>
<?php unset($__componentOriginal8445cfed575af5f8fe9105ababf279bed224606c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <div class="validation-message">
            <?php echo e($errors->first('mediaCollections.project_before_image')); ?>

        </div>
        <div class="help-block">
            <?php echo e(trans('cruds.project.fields.before_image_helper')); ?>

        </div>
    </div>
    <div class="form-group <?php echo e($errors->has('mediaCollections.project_after_image') ? 'invalid' : ''); ?>">
        <label class="form-label" for="after_image"><?php echo e(trans('cruds.project.fields.after_image')); ?></label>
        <?php if (isset($component)) { $__componentOriginal8445cfed575af5f8fe9105ababf279bed224606c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Dropzone::class, []); ?>
<?php $component->withName('dropzone'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['id' => 'after_image','name' => 'after_image','action' => ''.e(route('admin.projects.storeMedia')).'','collection-name' => 'project_after_image','max-file-size' => '1','max-width' => '1920','max-height' => '1080','max-files' => '1']); ?>
<?php if (isset($__componentOriginal8445cfed575af5f8fe9105ababf279bed224606c)): ?>
<?php $component = $__componentOriginal8445cfed575af5f8fe9105ababf279bed224606c; ?>
<?php unset($__componentOriginal8445cfed575af5f8fe9105ababf279bed224606c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <div class="validation-message">
            <?php echo e($errors->first('mediaCollections.project_after_image')); ?>

        </div>
        <div class="help-block">
            <?php echo e(trans('cruds.project.fields.after_image_helper')); ?>

        </div>
    </div>

    <div class="form-group">
        <button class="btn btn-indigo mr-2" type="submit">
            <?php echo e(trans('global.save')); ?>

        </button>
        <a href="<?php echo e(route('admin.projects.index')); ?>" class="btn btn-secondary">
            <?php echo e(trans('global.cancel')); ?>

        </a>
    </div>
</form><?php /**PATH C:\xampp_new\htdocs\yalla wrap it\resources\views/livewire/project/create.blade.php ENDPATH**/ ?>