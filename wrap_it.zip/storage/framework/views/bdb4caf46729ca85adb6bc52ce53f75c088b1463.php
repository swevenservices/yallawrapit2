<?php $__env->startSection('content'); ?>

<section class="relative w-full h-full py-40 min-h-screen">
    <div class="absolute top-0 w-full h-full bg-gray-900 bg-full bg-no-repeat" 
        ></div>
        <div class="container mx-auto px-4 h-full">
            <div class="flex content-center items-center justify-center h-full">
                <div class="w-full lg:w-4/12 px-4">
                    <div class="relative flex flex-col min-w-0 break-words w-full mb-6 shadow-lg rounded-lg bg-gray-300 border-0">
                        <div class="flex-auto px-4 lg:px-10 py-10 pt-6">
                            <div class="text-gray-500 text-center mb-3 font-bold">
                                <?php echo e(trans('global.login')); ?>

                            </div>

<?php if(session('message')): ?>
                                <div class="shadow bg-green-100 my-4 rounded p-2" role="alert">
                                    <?php echo e(session('message')); ?>

                                </div>
<?php endif; ?>

                            <form method="POST" action="<?php echo e(route('login')); ?>">
<?php echo csrf_field(); ?>

                                <div class="relative w-full mb-3">
                                    <label class="block uppercase text-gray-700 text-xs font-bold mb-2"
                                           for="email">
                                        <?php echo e(trans('global.login_email')); ?>

                                    </label>
                                    <input id="email"
                                           name="email"
                                           type="text"
                                           class="px-3 py-3 placeholder-gray-400 text-gray-700 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150<?php echo e($errors->has('email') ? ' border border-red-500' : ''); ?>"
                                           required
                                           autocomplete="email"
                                           autofocus
                                           placeholder="<?php echo e(trans('global.login_email')); ?>"
                                           value="<?php echo e(old('email', null)); ?>">

<?php if($errors->has('email')): ?>
                                        <div class="text-red-500">
                                            <?php echo e($errors->first('email')); ?>

                                        </div>
<?php endif; ?>
                                </div>

                                <div class="relative w-full mb-3">
                                    <label class="block uppercase text-gray-700 text-xs font-bold mb-2"
                                           for="grid-password">
                                        <?php echo e(trans('global.login_password')); ?>

                                    </label>
                                    <input id="password"
                                           name="password"
                                           type="password"
                                           class="px-3 py-3 placeholder-gray-400 text-gray-700 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150<?php echo e($errors->has('password') ? ' border border-red-500' : ''); ?>"
                                           required
                                           placeholder="<?php echo e(trans('global.login_password')); ?>">

<?php if($errors->has('password')): ?>
                                        <div class="text-red-500">
                                            <?php echo e($errors->first('password')); ?>

                                        </div>
<?php endif; ?>
                                </div>

                                <div>
                                    <label class="inline-flex items-center cursor-pointer">
                                        <input
                                                name="remember"
                                                type="checkbox"
                                                id="remember"
                                                class="form-checkbox text-gray-800 ml-1 w-5 h-5 ease-linear transition-all duration-150"/>
                                        <span class="ml-2 text-sm font-semibold text-gray-700"><?php echo e(trans('global.remember_me')); ?></span>
                                    </label>
                                </div>
                                <div class="text-center mt-6">
                                    <button
                                            class="bg-gray-900 text-white active:bg-gray-700 text-sm font-bold uppercase px-6 py-3 rounded shadow hover:shadow-lg outline-none focus:outline-none mr-1 mb-1 w-full ease-linear transition-all duration-150"
                                            type="submit">
                                        <?php echo e(trans('global.login')); ?>

                                    </button>
                                </div>
                                <div class="mt-6">
                                    <div class="flex flex-wrap mt-6">
<?php if(Route::has('password.request')): ?>
                                            <div class="w-1/2">
                                                <a href="<?php echo e(route('password.request')); ?>" class="">
                                                    <small>Forgot password?</small>
                                                </a>
                                            </div>
<?php endif; ?>
<?php if(Route::has('register')): ?>
                                            <div class="w-1/2 text-right">
                                                <a href="<?php echo e(route('register')); ?>" class="">
                                                    <small>
                                                        Create new account
                                                    </small>
                                                </a>
                                            </div>
<?php endif; ?>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_new\htdocs\yalla wrap it\resources\views/auth/login.blade.php ENDPATH**/ ?>