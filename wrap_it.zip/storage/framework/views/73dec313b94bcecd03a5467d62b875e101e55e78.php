<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="card bg-white">
        <div class="card-header border-b border-blueGray-200">
            <div class="card-header-container">
                <h6 class="card-title">
                    <?php echo e(trans('cruds.project.title_singular')); ?>

                    <?php echo e(trans('global.list')); ?>

                </h6>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('project_create')): ?>
                    <a class="btn btn-indigo" href="<?php echo e(route('admin.projects.create')); ?>">
                        <?php echo e(trans('global.add')); ?> <?php echo e(trans('cruds.project.title_singular')); ?>

                    </a>
                <?php endif; ?>
            </div>
        </div>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('project.index')->html();
} elseif ($_instance->childHasBeenRendered('BPtCGSA')) {
    $componentId = $_instance->getRenderedChildComponentId('BPtCGSA');
    $componentTag = $_instance->getRenderedChildComponentTagName('BPtCGSA');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('BPtCGSA');
} else {
    $response = \Livewire\Livewire::mount('project.index');
    $html = $response->html();
    $_instance->logRenderedChild('BPtCGSA', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_new\htdocs\yalla wrap it\resources\views/admin/project/index.blade.php ENDPATH**/ ?>