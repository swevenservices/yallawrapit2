<form wire:submit.prevent="submit" class="pt-3">

    <div class="form-group <?php echo e($errors->has('service.title') ? 'invalid' : ''); ?>">
        <label class="form-label required" for="title"><?php echo e(trans('cruds.service.fields.title')); ?></label>
        <input class="form-control" type="text" name="title" id="title" required wire:model.defer="service.title">
        <div class="validation-message">
            <?php echo e($errors->first('service.title')); ?>

        </div>
        <div class="help-block">
            <?php echo e(trans('cruds.service.fields.title_helper')); ?>

        </div>
    </div>
    <div class="form-group <?php echo e($errors->has('service.excerpt') ? 'invalid' : ''); ?>">
        <label class="form-label required" for="excerpt"><?php echo e(trans('cruds.service.fields.excerpt')); ?></label>
        <input class="form-control" type="text" name="excerpt" id="excerpt" required wire:model.defer="service.excerpt">
        <div class="validation-message">
            <?php echo e($errors->first('service.excerpt')); ?>

        </div>
        <div class="help-block">
            <?php echo e(trans('cruds.service.fields.excerpt_helper')); ?>

        </div>
    </div>
    <div class="form-group <?php echo e($errors->has('service.slug') ? 'invalid' : ''); ?>">
        <label class="form-label required" for="slug"><?php echo e(trans('cruds.service.fields.slug')); ?></label>
        <input class="form-control" type="text" name="slug" id="slug" required wire:model.defer="service.slug">
        <div class="validation-message">
            <?php echo e($errors->first('service.slug')); ?>

        </div>
        <div class="help-block">
            <?php echo e(trans('cruds.service.fields.slug_helper')); ?>

        </div>
    </div>
    <div class="form-group <?php echo e($errors->has('service.content') ? 'invalid' : ''); ?>">
        <label class="form-label required" for="content"><?php echo e(trans('cruds.service.fields.content')); ?></label>
        <textarea class="form-control" name="content" id="content" required wire:model.defer="service.content" rows="4"></textarea>
        <div class="validation-message">
            <?php echo e($errors->first('service.content')); ?>

        </div>
        <div class="help-block">
            <?php echo e(trans('cruds.service.fields.content_helper')); ?>

        </div>
    </div>
    <div class="form-group <?php echo e($errors->has('service.meta_title') ? 'invalid' : ''); ?>">
        <label class="form-label" for="meta_title"><?php echo e(trans('cruds.service.fields.meta_title')); ?></label>
        <input class="form-control" type="text" name="meta_title" id="meta_title" wire:model.defer="service.meta_title">
        <div class="validation-message">
            <?php echo e($errors->first('service.meta_title')); ?>

        </div>
        <div class="help-block">
            <?php echo e(trans('cruds.service.fields.meta_title_helper')); ?>

        </div>
    </div>
    <div class="form-group <?php echo e($errors->has('service.meta_content') ? 'invalid' : ''); ?>">
        <label class="form-label" for="meta_content"><?php echo e(trans('cruds.service.fields.meta_content')); ?></label>
        <input class="form-control" type="text" name="meta_content" id="meta_content" wire:model.defer="service.meta_content">
        <div class="validation-message">
            <?php echo e($errors->first('service.meta_content')); ?>

        </div>
        <div class="help-block">
            <?php echo e(trans('cruds.service.fields.meta_content_helper')); ?>

        </div>
    </div>
    <div class="form-group <?php echo e($errors->has('service.meta_description') ? 'invalid' : ''); ?>">
        <label class="form-label" for="meta_description"><?php echo e(trans('cruds.service.fields.meta_description')); ?></label>
        <input class="form-control" type="text" name="meta_description" id="meta_description" wire:model.defer="service.meta_description">
        <div class="validation-message">
            <?php echo e($errors->first('service.meta_description')); ?>

        </div>
        <div class="help-block">
            <?php echo e(trans('cruds.service.fields.meta_description_helper')); ?>

        </div>
    </div>
    <div class="form-group <?php echo e($errors->has('service.status') ? 'invalid' : ''); ?>">
        <label class="form-label" for="status"><?php echo e(trans('cruds.service.fields.status')); ?></label>
        <input class="form-control" type="checkbox" name="status" id="status" wire:model.defer="service.status">
        <div class="validation-message">
            <?php echo e($errors->first('service.status')); ?>

        </div>
        <div class="help-block">
            <?php echo e(trans('cruds.service.fields.status_helper')); ?>

        </div>
    </div>
    <div class="form-group <?php echo e($errors->has('mediaCollections.service_image') ? 'invalid' : ''); ?>">
        <label class="form-label" for="image"><?php echo e(trans('cruds.service.fields.image')); ?></label>
        <?php if (isset($component)) { $__componentOriginal8445cfed575af5f8fe9105ababf279bed224606c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Dropzone::class, []); ?>
<?php $component->withName('dropzone'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['id' => 'image','name' => 'image','action' => ''.e(route('admin.services.storeMedia')).'','collection-name' => 'service_image','max-file-size' => '2','max-width' => '4096','max-height' => '4096','max-files' => '1']); ?>
<?php if (isset($__componentOriginal8445cfed575af5f8fe9105ababf279bed224606c)): ?>
<?php $component = $__componentOriginal8445cfed575af5f8fe9105ababf279bed224606c; ?>
<?php unset($__componentOriginal8445cfed575af5f8fe9105ababf279bed224606c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <div class="validation-message">
            <?php echo e($errors->first('mediaCollections.service_image')); ?>

        </div>
        <div class="help-block">
            <?php echo e(trans('cruds.service.fields.image_helper')); ?>

        </div>
    </div>
    <div class="form-group <?php echo e($errors->has('projects') ? 'invalid' : ''); ?>">
        <label class="form-label" for="projects"><?php echo e(trans('cruds.service.fields.projects')); ?></label>
        <?php if (isset($component)) { $__componentOriginal27a1460291975da05a1f6dc019a28acd246e95fa = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SelectList::class, ['options' => $this->listsForFields['projects']]); ?>
<?php $component->withName('select-list'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'form-control','id' => 'projects','name' => 'projects','wire:model' => 'projects','multiple' => true]); ?>
<?php if (isset($__componentOriginal27a1460291975da05a1f6dc019a28acd246e95fa)): ?>
<?php $component = $__componentOriginal27a1460291975da05a1f6dc019a28acd246e95fa; ?>
<?php unset($__componentOriginal27a1460291975da05a1f6dc019a28acd246e95fa); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <div class="validation-message">
            <?php echo e($errors->first('projects')); ?>

        </div>
        <div class="help-block">
            <?php echo e(trans('cruds.service.fields.projects_helper')); ?>

        </div>
    </div>

    <div class="form-group">
        <button class="btn btn-indigo mr-2" type="submit">
            <?php echo e(trans('global.save')); ?>

        </button>
        <a href="<?php echo e(route('admin.services.index')); ?>" class="btn btn-secondary">
            <?php echo e(trans('global.cancel')); ?>

        </a>
    </div>
</form><?php /**PATH C:\xampp_new\htdocs\yalla wrap it\resources\views/livewire/service/create.blade.php ENDPATH**/ ?>