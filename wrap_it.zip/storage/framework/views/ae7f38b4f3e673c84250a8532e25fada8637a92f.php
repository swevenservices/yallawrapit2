<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="card bg-white">
        <div class="card-header border-b border-blueGray-200">
            <div class="card-header-container">
                <h6 class="card-title">
                    <?php echo e(trans('cruds.role.title_singular')); ?>

                    <?php echo e(trans('global.list')); ?>

                </h6>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role_create')): ?>
                    <a class="btn btn-indigo" href="<?php echo e(route('admin.roles.create')); ?>">
                        <?php echo e(trans('global.add')); ?> <?php echo e(trans('cruds.role.title_singular')); ?>

                    </a>
                <?php endif; ?>
            </div>
        </div>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('role.index')->html();
} elseif ($_instance->childHasBeenRendered('TpabNOA')) {
    $componentId = $_instance->getRenderedChildComponentId('TpabNOA');
    $componentTag = $_instance->getRenderedChildComponentTagName('TpabNOA');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('TpabNOA');
} else {
    $response = \Livewire\Livewire::mount('role.index');
    $html = $response->html();
    $_instance->logRenderedChild('TpabNOA', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_new\htdocs\yalla wrap it\resources\views/admin/role/index.blade.php ENDPATH**/ ?>