<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="theme-color" content="#000000" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css" integrity="sha512-HK5fgLBL+xu6dm/Ii3z4xhlSUyZgTT9tuc/hSrtw6uzJOvgRr2a9jyxxT1ely+B+xFAmJKVSTbpM/CuL7qxO8w==" crossorigin="anonymous" />
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>" />
    <title><?php echo e(trans('panel.site_title')); ?></title>
    <?php echo \Livewire\Livewire::styles(); ?>

</head>

<body class="text-blueGray-800 antialiased">

    <noscript>You need to enable JavaScript to run this app.</noscript>

    <div id="app">

        <div class="relative bg-gray-100 min-h-screen">
            <div class="relative mx-auto w-full min-h-full">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>

    </div>

    <form id="logoutform" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
        <?php echo e(csrf_field()); ?>

    </form>

    <script type="text/javascript" src="<?php echo e(asset('js/app.js')); ?>"></script>
    <?php echo \Livewire\Livewire::scripts(); ?>

</body>

</html><?php /**PATH C:\xampp_new\htdocs\yalla wrap it\resources\views/layouts/app.blade.php ENDPATH**/ ?>