<div class="row">

    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-lg-4 col-md-6 col-sm-6">
        <div class="single-blog-post">
            <div class="post-image">
                <?php $__currentLoopData = $service->image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <img class="img-fluid" data-label="Before" src="<?php echo e($image['preview_thumbnail']); ?>">
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="post-content">
                <h3><a href="single-blog.html"><?php echo e($service->title); ?></a></h3>
                <p><?php echo e($service->excerpt); ?></p>
                <a href="single-blog.html" class="read-more-btn">Read More <i class="flaticon-right-chevron"></i></a>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH C:\xampp_new\htdocs\yalla wrap it\resources\views/livewire/front-end/services.blade.php ENDPATH**/ ?>