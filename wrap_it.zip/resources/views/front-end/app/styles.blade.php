  <!-- Bootstrap Min CSS -->
  <link rel="stylesheet" href="{{ asset('front-end') }}/css/bootstrap.min.css">
  <!-- Animation Min CSS -->
  <link rel="stylesheet" href="{{ asset('front-end') }}/css/animate.min.css">
  <!-- Font Awesome Min CSS -->
  <link rel="stylesheet" href="{{ asset('front-end') }}/css/fontawesome.min.css">
  <!-- FlatIcon CSS -->
  <link rel="stylesheet" href="{{ asset('front-end') }}/css/flaticon.css">
  <!-- Magnific Popup Min CSS -->
  <link rel="stylesheet" href="{{ asset('front-end') }}/css/magnific-popup.min.css">
  <!-- Mean Menu CSS -->
  <link rel="stylesheet" href="{{ asset('front-end') }}/css/meanmenu.css">
  <!-- Odometer Min CSS -->
  <link rel="stylesheet" href="{{ asset('front-end') }}/css/odometer.min.css">
  <!-- Nice Select Min CSS -->
  <link rel="stylesheet" href="{{ asset('front-end') }}/css/nice-select.min.css">
  <!-- Owl Carousel Min CSS -->
  <link rel="stylesheet" href="{{ asset('front-end') }}/css/owl.carousel.min.css">
  <!-- Style CSS -->
  <link rel="stylesheet" href="{{ asset('front-end') }}/css/style.css">
  <!-- Responsive CSS -->
  <link rel="stylesheet" href="{{ asset('front-end') }}/css/responsive.css">

  <title>Zovio - Interior Design and Architecture HTML Template</title>

  <link rel="icon" type="image/png" href="{{ asset('front-end') }}/img/favicon.png">
  @livewireStyles
