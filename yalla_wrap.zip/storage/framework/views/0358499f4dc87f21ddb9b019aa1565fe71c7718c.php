<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="card bg-blueGray-100">
        <div class="card-header">
            <div class="card-header-container">
                <h6 class="card-title">
                    <?php echo e(trans('global.create')); ?>

                    <?php echo e(trans('cruds.category.title_singular')); ?>

                </h6>
            </div>
        </div>

        <div class="card-body">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('category.create')->html();
} elseif ($_instance->childHasBeenRendered('0y5G2V7')) {
    $componentId = $_instance->getRenderedChildComponentId('0y5G2V7');
    $componentTag = $_instance->getRenderedChildComponentTagName('0y5G2V7');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('0y5G2V7');
} else {
    $response = \Livewire\Livewire::mount('category.create');
    $html = $response->html();
    $_instance->logRenderedChild('0y5G2V7', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_new\htdocs\yalla wrap it\resources\views/admin/category/create.blade.php ENDPATH**/ ?>