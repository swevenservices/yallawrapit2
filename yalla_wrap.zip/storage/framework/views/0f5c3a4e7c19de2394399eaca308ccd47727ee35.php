<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="card bg-blueGray-100">
        <div class="card-header">
            <div class="card-header-container">
                <h6 class="card-title">
                    <?php echo e(trans('global.create')); ?>

                    <?php echo e(trans('cruds.service.title_singular')); ?>

                </h6>
            </div>
        </div>

        <div class="card-body">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('service.create')->html();
} elseif ($_instance->childHasBeenRendered('LraNL86')) {
    $componentId = $_instance->getRenderedChildComponentId('LraNL86');
    $componentTag = $_instance->getRenderedChildComponentTagName('LraNL86');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('LraNL86');
} else {
    $response = \Livewire\Livewire::mount('service.create');
    $html = $response->html();
    $_instance->logRenderedChild('LraNL86', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_new\htdocs\yalla wrap it\resources\views/admin/service/create.blade.php ENDPATH**/ ?>