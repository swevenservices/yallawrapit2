<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="card bg-blueGray-100">
        <div class="card-header">
            <div class="card-header-container">
                <h6 class="card-title">
                    <?php echo e(trans('global.create')); ?>

                    <?php echo e(trans('cruds.project.title_singular')); ?>

                </h6>
            </div>
        </div>

        <div class="card-body">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('project.create')->html();
} elseif ($_instance->childHasBeenRendered('FXcn1yr')) {
    $componentId = $_instance->getRenderedChildComponentId('FXcn1yr');
    $componentTag = $_instance->getRenderedChildComponentTagName('FXcn1yr');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('FXcn1yr');
} else {
    $response = \Livewire\Livewire::mount('project.create');
    $html = $response->html();
    $_instance->logRenderedChild('FXcn1yr', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_new\htdocs\yalla wrap it\resources\views/admin/project/create.blade.php ENDPATH**/ ?>