<div class="contact-form">
    <?php if(session()->has('message')): ?>
    <div class="col-md-12 alert alert-success">
        <?php echo e(session('message')); ?>

    </div>
    <?php endif; ?>
    <form wire:submit.prevent="submit" >
        <div class="row">
            <?php if($service): ?>
            <div class="col-lg-12 col-md-12">
                <div class="form-group">
                    <input type="text" readonly wire:model.defer="contact.service" name="service" id="service"  class="form-control <?php echo e($errors->has('contact.service') ? 'is-invalid' : ''); ?>" value="">
                    <?php $__errorArgs = ['contact.service'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-red ml-md-2"> <?php echo e(str_replace('contact.', '', $message)); ?> </div>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>
            </div>
            <?php endif; ?>
            <div class="col-lg-6 col-md-6">
                <div class="form-group">

                    <input type="text" wire:model.defer="contact.name" wire name="name" id="name" class="form-control <?php echo e($errors->has('contact.name') ? 'is-invalid' : ''); ?> " required data-error="Please enter your name" placeholder="Name">
                    <?php $__errorArgs = ['contact.name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-red ml-md-2"> <?php echo e(str_replace('contact.', '', $message)); ?> </div>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="col-lg-6 col-md-6">
                <div class="form-group">
                    <input  type="email" wire:model.defer="contact.email" name="email" id="email" class="form-control <?php echo e($errors->has('contact.email') ? 'is-invalid' : ''); ?>" required data-error="Please enter your email" placeholder="Email">
                    <?php $__errorArgs = ['contact.email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-red ml-md-2"> <?php echo e(str_replace('contact.', '', $message)); ?> </div>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>
            </div>
            <div class="col-lg-12 col-md-12">
                <div class="form-group">
                    <input type="text" wire:model.defer="contact.phone" name="phone_number" id="phone_number" required data-error="Please enter your number" class="form-control <?php echo e($errors->has('contact.phone') ? 'is-invalid' : ''); ?>" placeholder="Phone">
                    <?php $__errorArgs = ['contact.phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-red ml-md-2"> <?php echo e(str_replace('contact.', '', $message)); ?> </div>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>
            </div>
            <div class="col-lg-12 col-md-12">
                <div class="form-group">
                    <input type="text" wire:model.defer="contact.phone" name="phone_number" id="phone_number" required data-error="Please enter your number" class="form-control <?php echo e($errors->has('contact.phone') ? 'is-invalid' : ''); ?>" placeholder="Phone">
                    <?php $__errorArgs = ['contact.phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-red ml-md-2"> <?php echo e(str_replace('contact.', '', $message)); ?> </div>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>
            </div>
            <div class="col-lg-12 col-md-12">
                <div class="form-group">
                    <textarea wire:model.defer="contact.message" name="message" class="form-control <?php echo e($errors->has('contact.message') ? 'is-invalid' : ''); ?>" id="message" cols="30" rows="6" required data-error="Write your message" placeholder="Your Message"></textarea>
                    <?php echo e($errors->has('contact.message') ? 'is-invalid' : ''); ?>

                </div>
            </div>
            <div class="col-lg-12 col-md-12">
                    <button wire:loading.remove wire:click.prevent="submit" name="save" value="save" type="submit"
                    class="default-btn">    <?php if($service): ?>  Book Service <?php else: ?> Send Message  <?php endif; ?>
                    </button>
                    <button wire:loading.table class="default-btn"
                     type="button" disabled style="display: none">   <i class="fa fa-spinner fa-spin" aria-hidden="true"></i>
                     <?php if($service): ?>  Book Service <?php else: ?> Send Message  <?php endif; ?>
                    </button>
            </div>
        </div>
    </form>
</div>
<?php /**PATH C:\xampp_new\htdocs\yalla wrap it\resources\views/livewire/front-end/contact.blade.php ENDPATH**/ ?>