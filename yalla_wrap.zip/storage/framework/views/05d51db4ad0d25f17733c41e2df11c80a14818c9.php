<form wire:submit.prevent="submit" class="pt-3">

    <div class="form-group <?php echo e($errors->has('tag.title') ? 'invalid' : ''); ?>">
        <label class="form-label required" for="title"><?php echo e(trans('cruds.tag.fields.title')); ?></label>
        <input class="form-control" type="text" name="title" id="title" required wire:model.defer="tag.title">
        <div class="validation-message">
            <?php echo e($errors->first('tag.title')); ?>

        </div>
        <div class="help-block">
            <?php echo e(trans('cruds.tag.fields.title_helper')); ?>

        </div>
    </div>
    <div class="form-group <?php echo e($errors->has('tag.slug') ? 'invalid' : ''); ?>">
        <label class="form-label required" for="slug"><?php echo e(trans('cruds.tag.fields.slug')); ?></label>
        <input class="form-control" type="text" name="slug" id="slug" required wire:model.defer="tag.slug">
        <div class="validation-message">
            <?php echo e($errors->first('tag.slug')); ?>

        </div>
        <div class="help-block">
            <?php echo e(trans('cruds.tag.fields.slug_helper')); ?>

        </div>
    </div>
    <div class="form-group <?php echo e($errors->has('tag.status') ? 'invalid' : ''); ?>">
        <label class="form-label" for="status"><?php echo e(trans('cruds.tag.fields.status')); ?></label>
        <input class="form-control" type="checkbox" name="status" id="status" wire:model.defer="tag.status">
        <div class="validation-message">
            <?php echo e($errors->first('tag.status')); ?>

        </div>
        <div class="help-block">
            <?php echo e(trans('cruds.tag.fields.status_helper')); ?>

        </div>
    </div>

    <div class="form-group">
        <button class="btn btn-indigo mr-2" type="submit">
            <?php echo e(trans('global.save')); ?>

        </button>
        <a href="<?php echo e(route('admin.tags.index')); ?>" class="btn btn-secondary">
            <?php echo e(trans('global.cancel')); ?>

        </a>
    </div>
</form><?php /**PATH C:\xampp_new\htdocs\yalla wrap it\resources\views/livewire/tag/create.blade.php ENDPATH**/ ?>