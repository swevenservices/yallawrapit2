<form wire:submit.prevent="submit" class="pt-3">

    <div class="form-group <?php echo e($errors->has('category.title') ? 'invalid' : ''); ?>">
        <label class="form-label required" for="title"><?php echo e(trans('cruds.category.fields.title')); ?></label>
        <input class="form-control" type="text" name="title" id="title" required wire:model.defer="category.title">
        <div class="validation-message">
            <?php echo e($errors->first('category.title')); ?>

        </div>
        <div class="help-block">
            <?php echo e(trans('cruds.category.fields.title_helper')); ?>

        </div>
    </div>
    <div class="form-group <?php echo e($errors->has('category.slug') ? 'invalid' : ''); ?>">
        <label class="form-label required" for="slug"><?php echo e(trans('cruds.category.fields.slug')); ?></label>
        <input class="form-control" type="text" name="slug" id="slug" required wire:model.defer="category.slug">
        <div class="validation-message">
            <?php echo e($errors->first('category.slug')); ?>

        </div>
        <div class="help-block">
            <?php echo e(trans('cruds.category.fields.slug_helper')); ?>

        </div>
    </div>
    <div class="form-group <?php echo e($errors->has('category.status') ? 'invalid' : ''); ?>">
        <label class="form-label" for="status"><?php echo e(trans('cruds.category.fields.status')); ?></label>
        <input class="form-control" type="checkbox" name="status" id="status" wire:model.defer="category.status">
        <div class="validation-message">
            <?php echo e($errors->first('category.status')); ?>

        </div>
        <div class="help-block">
            <?php echo e(trans('cruds.category.fields.status_helper')); ?>

        </div>
    </div>

    <div class="form-group">
        <button class="btn btn-indigo mr-2" type="submit">
            <?php echo e(trans('global.save')); ?>

        </button>
        <a href="<?php echo e(route('admin.categories.index')); ?>" class="btn btn-secondary">
            <?php echo e(trans('global.cancel')); ?>

        </a>
    </div>
</form><?php /**PATH C:\xampp_new\htdocs\yalla wrap it\resources\views/livewire/category/create.blade.php ENDPATH**/ ?>