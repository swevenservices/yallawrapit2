 <!-- jQuery Min JS -->
  <script src="<?php echo e(asset('front-end')); ?>/js/jquery.min.js"></script>
      <!-- cdnjs -->
      <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery.lazy/1.7.9/jquery.lazy.min.js"></script>
      <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery.lazy/1.7.9/jquery.lazy.plugins.min.js"></script>


<script>
     $(function() {
        $('.lazy').Lazy();
    });
    </script>
  <!-- Popper Min JS -->
  <script src="<?php echo e(asset('front-end')); ?>/js/popper.min.js" defer></script>
  <!-- Bootstrap Min JS -->
  <script src="<?php echo e(asset('front-end')); ?>/js/bootstrap.min.js"></script>
  <!-- Owl Carousel Min JS -->
  <script src="<?php echo e(asset('front-end')); ?>/js/owl.carousel.min.js"></script>
  <!-- magnific Popup Min JS -->
  <script src="<?php echo e(asset('front-end')); ?>/js/jquery.magnific-popup.min.js"></script>
  <!-- Appear Min JS -->
  <script src="<?php echo e(asset('front-end')); ?>/js/jquery.appear.min.js"></script>
  <!-- Mean Menu JS -->
 <script src="<?php echo e(asset('front-end')); ?>/js/jquery.meanmenu.js"></script>

<script src="<?php echo e(asset('front-end')); ?>/js/main.js"></script>

<script src="https://cdn.knightlab.com/libs/juxtapose/latest/js/juxtapose.min.js"></script>
<link rel="stylesheet" href="https://cdn.knightlab.com/libs/juxtapose/latest/css/juxtapose.css">

<?php echo \Livewire\Livewire::scripts(); ?>

<?php /**PATH C:\xampp_new\htdocs\yalla wrap it\resources\views/front-end/app/scripts.blade.php ENDPATH**/ ?>