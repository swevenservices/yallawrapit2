<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="card bg-blueGray-100">
        <div class="card-header">
            <div class="card-header-container">
                <h6 class="card-title">
                    <?php echo e(trans('global.view')); ?>

                    <?php echo e(trans('cruds.contact.title_singular')); ?>:
                    <?php echo e(trans('cruds.contact.fields.id')); ?>

                    <?php echo e($contact->id); ?>

                </h6>
            </div>
        </div>

        <div class="card-body">
            <div class="pt-3">
                <table class="table table-view">
                    <tbody class="bg-white">
                        <tr>
                            <th>
                                <?php echo e(trans('cruds.contact.fields.id')); ?>

                            </th>
                            <td>
                                <?php echo e($contact->id); ?>

                            </td>
                        </tr>
                        <tr>
                            <th>
                                <?php echo e(trans('cruds.contact.fields.name')); ?>

                            </th>
                            <td>
                                <?php echo e($contact->name); ?>

                            </td>
                        </tr>
                        <tr>
                            <th>
                                <?php echo e(trans('cruds.contact.fields.email')); ?>

                            </th>
                            <td>
                                <?php echo e($contact->email); ?>

                            </td>
                        </tr>
                        <tr>
                            <th>
                                <?php echo e(trans('cruds.contact.fields.phone')); ?>

                            </th>
                            <td>
                                <?php echo e($contact->phone); ?>

                            </td>
                        </tr>
                        <tr>
                            <th>
                                <?php echo e(trans('cruds.contact.fields.message')); ?>

                            </th>
                            <td>
                                <?php echo e($contact->message); ?>

                            </td>
                        </tr>
                        <tr>
                            <th>
                                <?php echo e(trans('cruds.contact.fields.service')); ?>

                            </th>
                            <td>
                                <?php echo e($contact->service); ?>

                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="form-group">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('contact_edit')): ?>
                    <a href="<?php echo e(route('admin.contacts.edit', $contact)); ?>" class="btn btn-indigo mr-2">
                        <?php echo e(trans('global.edit')); ?>

                    </a>
                <?php endif; ?>
                <a href="<?php echo e(route('admin.contacts.index')); ?>" class="btn btn-secondary">
                    <?php echo e(trans('global.back')); ?>

                </a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_new\htdocs\yalla wrap it\resources\views/admin/contact/show.blade.php ENDPATH**/ ?>