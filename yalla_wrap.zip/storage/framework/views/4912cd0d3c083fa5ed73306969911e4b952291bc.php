<?php $__env->startSection('content'); ?>

    <!-- Start Page Title Area Area -->
    <div class="page-title-area page-title-bg5 jarallax" data-jarallax='{"speed": 0.3}'>
        <div class="d-table">
            <div class="d-table-cell">
                <div class="container">
                    <div class="page-title-content">
                        <h2>Serivces Details</h2>
                        <p><?php echo e($service->title); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
  <!-- Start Services Details Area -->
        <section class="services-details-area ptb-100">
            <div class="container">
                <div class="row">
                    <div class="col-lg-7 col-md-12">
                        <div class="services-details-desc">
                            <div class="services-details-image">
                                <?php $__currentLoopData = $service->image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <img class="img-fluid" data-label="Before" src="<?php echo e($image['url']); ?>">
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                            <h3><?php echo e($service->title); ?></h3>

                            <p><?php echo e($service->excerpt); ?></p>
                            <p>
                                <?php echo e($service->content); ?>

                            </p>
                          </div>
                    </div>

                    <div class="col-lg-5 col-md-12">
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('front-end.contact',  ['service' => $service ])->html();
} elseif ($_instance->childHasBeenRendered('X5iTNgZ')) {
    $componentId = $_instance->getRenderedChildComponentId('X5iTNgZ');
    $componentTag = $_instance->getRenderedChildComponentTagName('X5iTNgZ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('X5iTNgZ');
} else {
    $response = \Livewire\Livewire::mount('front-end.contact',  ['service' => $service ]);
    $html = $response->html();
    $_instance->logRenderedChild('X5iTNgZ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Services Details Area -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('front-end.app.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_new\htdocs\yalla wrap it\resources\views/front-end/services/_slug.blade.php ENDPATH**/ ?>