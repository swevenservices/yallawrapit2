<form wire:submit.prevent="submit" class="pt-3">

    <div class="form-group <?php echo e($errors->has('post.title') ? 'invalid' : ''); ?>">
        <label class="form-label required" for="title"><?php echo e(trans('cruds.post.fields.title')); ?></label>
        <input class="form-control" type="text" name="title" id="title" required wire:model.defer="post.title">
        <div class="validation-message">
            <?php echo e($errors->first('post.title')); ?>

        </div>
        <div class="help-block">
            <?php echo e(trans('cruds.post.fields.title_helper')); ?>

        </div>
    </div>
    <div class="form-group <?php echo e($errors->has('post.excerpt') ? 'invalid' : ''); ?>">
        <label class="form-label required" for="excerpt"><?php echo e(trans('cruds.post.fields.excerpt')); ?></label>
        <textarea class="form-control" name="excerpt" id="excerpt" required wire:model.defer="post.excerpt" rows="4"></textarea>
        <div class="validation-message">
            <?php echo e($errors->first('post.excerpt')); ?>

        </div>
        <div class="help-block">
            <?php echo e(trans('cruds.post.fields.excerpt_helper')); ?>

        </div>
    </div>
    <div class="form-group <?php echo e($errors->has('post.slug') ? 'invalid' : ''); ?>">
        <label class="form-label required" for="slug"><?php echo e(trans('cruds.post.fields.slug')); ?></label>
        <input class="form-control" type="text" name="slug" id="slug" required wire:model.defer="post.slug">
        <div class="validation-message">
            <?php echo e($errors->first('post.slug')); ?>

        </div>
        <div class="help-block">
            <?php echo e(trans('cruds.post.fields.slug_helper')); ?>

        </div>
    </div>
    <div class="form-group <?php echo e($errors->has('mediaCollections.post_image') ? 'invalid' : ''); ?>">
        <label class="form-label" for="image"><?php echo e(trans('cruds.post.fields.image')); ?></label>
        <?php if (isset($component)) { $__componentOriginal8445cfed575af5f8fe9105ababf279bed224606c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Dropzone::class, []); ?>
<?php $component->withName('dropzone'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['id' => 'image','name' => 'image','action' => ''.e(route('admin.posts.storeMedia')).'','collection-name' => 'post_image','max-file-size' => '1','max-width' => '1920','max-height' => '1080','max-files' => '1']); ?>
<?php if (isset($__componentOriginal8445cfed575af5f8fe9105ababf279bed224606c)): ?>
<?php $component = $__componentOriginal8445cfed575af5f8fe9105ababf279bed224606c; ?>
<?php unset($__componentOriginal8445cfed575af5f8fe9105ababf279bed224606c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <div class="validation-message">
            <?php echo e($errors->first('mediaCollections.post_image')); ?>

        </div>
        <div class="help-block">
            <?php echo e(trans('cruds.post.fields.image_helper')); ?>

        </div>
    </div>
    <div class="form-group <?php echo e($errors->has('post.content') ? 'invalid' : ''); ?>">
        <label class="form-label" for="content"><?php echo e(trans('cruds.post.fields.content')); ?></label>
        <textarea class="form-control" name="content" id="content" wire:model.defer="post.content" rows="4"></textarea>
        <div class="validation-message">
            <?php echo e($errors->first('post.content')); ?>

        </div>
        <div class="help-block">
            <?php echo e(trans('cruds.post.fields.content_helper')); ?>

        </div>
    </div>
    <div class="form-group <?php echo e($errors->has('post.status') ? 'invalid' : ''); ?>">
        <label class="form-label"><?php echo e(trans('cruds.post.fields.status')); ?></label>
        <?php $__currentLoopData = $this->listsForFields['status']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <label class="radio-label"><input type="radio" name="status" wire:model="post.status" value="<?php echo e($key); ?>"><?php echo e($value); ?></label>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="validation-message">
            <?php echo e($errors->first('post.status')); ?>

        </div>
        <div class="help-block">
            <?php echo e(trans('cruds.post.fields.status_helper')); ?>

        </div>
    </div>
    <div class="form-group <?php echo e($errors->has('post.meta_title') ? 'invalid' : ''); ?>">
        <label class="form-label" for="meta_title"><?php echo e(trans('cruds.post.fields.meta_title')); ?></label>
        <input class="form-control" type="text" name="meta_title" id="meta_title" wire:model.defer="post.meta_title">
        <div class="validation-message">
            <?php echo e($errors->first('post.meta_title')); ?>

        </div>
        <div class="help-block">
            <?php echo e(trans('cruds.post.fields.meta_title_helper')); ?>

        </div>
    </div>
    <div class="form-group <?php echo e($errors->has('post.meta_description') ? 'invalid' : ''); ?>">
        <label class="form-label" for="meta_description"><?php echo e(trans('cruds.post.fields.meta_description')); ?></label>
        <input class="form-control" type="text" name="meta_description" id="meta_description" wire:model.defer="post.meta_description">
        <div class="validation-message">
            <?php echo e($errors->first('post.meta_description')); ?>

        </div>
        <div class="help-block">
            <?php echo e(trans('cruds.post.fields.meta_description_helper')); ?>

        </div>
    </div>
    <div class="form-group <?php echo e($errors->has('post.meta_content') ? 'invalid' : ''); ?>">
        <label class="form-label" for="meta_content"><?php echo e(trans('cruds.post.fields.meta_content')); ?></label>
        <input class="form-control" type="text" name="meta_content" id="meta_content" wire:model.defer="post.meta_content">
        <div class="validation-message">
            <?php echo e($errors->first('post.meta_content')); ?>

        </div>
        <div class="help-block">
            <?php echo e(trans('cruds.post.fields.meta_content_helper')); ?>

        </div>
    </div>
    <div class="form-group <?php echo e($errors->has('post.catgeory_id') ? 'invalid' : ''); ?>">
        <label class="form-label" for="catgeory"><?php echo e(trans('cruds.post.fields.catgeory')); ?></label>
        <?php if (isset($component)) { $__componentOriginal27a1460291975da05a1f6dc019a28acd246e95fa = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SelectList::class, ['options' => $this->listsForFields['catgeory']]); ?>
<?php $component->withName('select-list'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'form-control','id' => 'catgeory','name' => 'catgeory','wire:model' => 'post.catgeory_id']); ?>
<?php if (isset($__componentOriginal27a1460291975da05a1f6dc019a28acd246e95fa)): ?>
<?php $component = $__componentOriginal27a1460291975da05a1f6dc019a28acd246e95fa; ?>
<?php unset($__componentOriginal27a1460291975da05a1f6dc019a28acd246e95fa); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <div class="validation-message">
            <?php echo e($errors->first('post.catgeory_id')); ?>

        </div>
        <div class="help-block">
            <?php echo e(trans('cruds.post.fields.catgeory_helper')); ?>

        </div>
    </div>
    <div class="form-group <?php echo e($errors->has('tags') ? 'invalid' : ''); ?>">
        <label class="form-label" for="tags"><?php echo e(trans('cruds.post.fields.tags')); ?></label>
        <?php if (isset($component)) { $__componentOriginal27a1460291975da05a1f6dc019a28acd246e95fa = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SelectList::class, ['options' => $this->listsForFields['tags']]); ?>
<?php $component->withName('select-list'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'form-control','id' => 'tags','name' => 'tags','wire:model' => 'tags','multiple' => true]); ?>
<?php if (isset($__componentOriginal27a1460291975da05a1f6dc019a28acd246e95fa)): ?>
<?php $component = $__componentOriginal27a1460291975da05a1f6dc019a28acd246e95fa; ?>
<?php unset($__componentOriginal27a1460291975da05a1f6dc019a28acd246e95fa); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <div class="validation-message">
            <?php echo e($errors->first('tags')); ?>

        </div>
        <div class="help-block">
            <?php echo e(trans('cruds.post.fields.tags_helper')); ?>

        </div>
    </div>

    <div class="form-group">
        <button class="btn btn-indigo mr-2" type="submit">
            <?php echo e(trans('global.save')); ?>

        </button>
        <a href="<?php echo e(route('admin.posts.index')); ?>" class="btn btn-secondary">
            <?php echo e(trans('global.cancel')); ?>

        </a>
    </div>
</form><?php /**PATH C:\xampp_new\htdocs\yalla wrap it\resources\views/livewire/post/create.blade.php ENDPATH**/ ?>