<?php echo e($slot); ?>

<?php /**PATH C:\xampp_new\htdocs\yalla wrap it\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>