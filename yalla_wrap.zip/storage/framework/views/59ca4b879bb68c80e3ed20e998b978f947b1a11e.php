<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="card bg-blueGray-100">
        <div class="card-header">
            <div class="card-header-container">
                <h6 class="card-title">
                    <?php echo e(trans('global.create')); ?>

                    <?php echo e(trans('cruds.tag.title_singular')); ?>

                </h6>
            </div>
        </div>

        <div class="card-body">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('tag.create')->html();
} elseif ($_instance->childHasBeenRendered('z0JyIJG')) {
    $componentId = $_instance->getRenderedChildComponentId('z0JyIJG');
    $componentTag = $_instance->getRenderedChildComponentTagName('z0JyIJG');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('z0JyIJG');
} else {
    $response = \Livewire\Livewire::mount('tag.create');
    $html = $response->html();
    $_instance->logRenderedChild('z0JyIJG', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_new\htdocs\yalla wrap it\resources\views/admin/tag/create.blade.php ENDPATH**/ ?>