<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="card bg-blueGray-100">
        <div class="card-header">
            <div class="card-header-container">
                <h6 class="card-title">
                    <?php echo e(trans('global.create')); ?>

                    <?php echo e(trans('cruds.post.title_singular')); ?>

                </h6>
            </div>
        </div>

        <div class="card-body">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('post.create')->html();
} elseif ($_instance->childHasBeenRendered('lsofx4g')) {
    $componentId = $_instance->getRenderedChildComponentId('lsofx4g');
    $componentTag = $_instance->getRenderedChildComponentTagName('lsofx4g');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('lsofx4g');
} else {
    $response = \Livewire\Livewire::mount('post.create');
    $html = $response->html();
    $_instance->logRenderedChild('lsofx4g', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_new\htdocs\yalla wrap it\resources\views/admin/post/create.blade.php ENDPATH**/ ?>