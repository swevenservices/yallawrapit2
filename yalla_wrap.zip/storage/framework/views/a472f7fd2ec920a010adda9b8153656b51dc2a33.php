<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="card bg-blueGray-100">
        <div class="card-header">
            <div class="card-header-container">
                <h6 class="card-title">
                    <?php echo e(trans('global.create')); ?>

                    <?php echo e(trans('cruds.contact.title_singular')); ?>

                </h6>
            </div>
        </div>

        <div class="card-body">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('contact.create')->html();
} elseif ($_instance->childHasBeenRendered('fImY0TT')) {
    $componentId = $_instance->getRenderedChildComponentId('fImY0TT');
    $componentTag = $_instance->getRenderedChildComponentTagName('fImY0TT');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('fImY0TT');
} else {
    $response = \Livewire\Livewire::mount('contact.create');
    $html = $response->html();
    $_instance->logRenderedChild('fImY0TT', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_new\htdocs\yalla wrap it\resources\views/admin/contact/create.blade.php ENDPATH**/ ?>