<?php $__env->startSection('content'); ?>

        <!-- Start Page Title Area Area -->
        <div class="page-title-area page-title-bg5 jarallax" data-jarallax='{"speed": 0.3}'>
            <div class="d-table">
                <div class="d-table-cell">
                    <div class="container">
                        <div class="page-title-content">
                            <h2>Projects</h2>
                            <p>Latest From Work</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Page Title Area Area -->

        <!-- Start Projects Area -->
        <section class="projects-area ptb-100">
            <div class="container">
                <div class="row">
                    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <div class="col-lg-6 col-md-6 col-sm-6">
                         <div class="single-projects-box">
                           <div class="juxtapose">
                                $<?php $__currentLoopData = $project->before_image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $beforeImage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <img class="img-fluid" data-label="Before" src="<?php echo e($beforeImage['preview_thumbnail']); ?>">
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             $<?php $__currentLoopData = $project->after_image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $afterImage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <img class="img-fluid" data-label="After" src="<?php echo e($afterImage['preview_thumbnail']); ?>">
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </div>

                        </div>
                     </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-12 col-md-12">
                        <div class="pagination-area">
                            <?php echo e($projects->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Projects Area -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front-end.app.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_new\htdocs\yalla wrap it\resources\views/front-end/projects.blade.php ENDPATH**/ ?>