<nav class="md:left-0 md:block md:fixed md:top-0 md:bottom-0 md:overflow-y-auto md:flex-row md:flex-nowrap md:overflow-hidden shadow-xl bg-white flex flex-wrap items-center justify-between relative md:w-64 z-10 py-4 px-6">
    <div class="md:flex-col md:items-stretch md:min-h-full md:flex-nowrap px-0 flex flex-wrap items-center justify-between w-full mx-auto">
        <button class="cursor-pointer text-black opacity-50 md:hidden px-3 py-1 text-xl leading-none bg-transparent rounded border border-solid border-transparent" type="button" onclick="toggleNavbar('example-collapse-sidebar')">
            <i class="fas fa-bars"></i>
        </button>
        <a class="md:block text-left md:pb-2 text-blueGray-700 mr-0 inline-block whitespace-nowrap text-sm uppercase font-bold p-4 px-0" href="<?php echo e(route('admin.home')); ?>">
            <?php echo e(trans('panel.site_title')); ?>

        </a>
        <div class="md:flex md:flex-col md:items-stretch md:opacity-100 md:relative md:mt-4 md:shadow-none shadow absolute top-0 left-0 right-0 z-40 overflow-y-auto overflow-x-hidden h-auto items-center flex-1 rounded hidden" id="example-collapse-sidebar">
            <div class="md:min-w-full md:hidden block pb-4 mb-4 border-b border-solid border-blueGray-300">
                <div class="flex flex-wrap">
                    <div class="w-6/12">
                        <a class="md:block text-left md:pb-2 text-blueGray-700 mr-0 inline-block whitespace-nowrap text-sm uppercase font-bold p-4 px-0" href="<?php echo e(route('admin.home')); ?>">
                            <?php echo e(trans('panel.site_title')); ?>

                        </a>
                    </div>
                    <div class="w-6/12 flex justify-end">
                        <button type="button" class="cursor-pointer text-black opacity-50 md:hidden px-3 py-1 text-xl leading-none bg-transparent rounded border border-solid border-transparent" onclick="toggleNavbar('example-collapse-sidebar')">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                </div>
            </div>



            <!-- Divider -->
            <hr class="mb-6 md:min-w-full" />
            <!-- Heading -->

            <ul class="md:flex-col md:min-w-full flex flex-col list-none">
                <li class="items-center">
                    <a href="<?php echo e(route("admin.home")); ?>" class="<?php echo e(request()->is("admin") ? "sidebar-nav-active" : "sidebar-nav"); ?>">
                        <i class="fas fa-tv"></i>
                        <?php echo e(trans('global.dashboard')); ?>

                    </a>
                </li>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_management_access')): ?>
                    <li class="items-center">
                        <a class="has-sub <?php echo e(request()->is("admin/permissions*")||request()->is("admin/roles*")||request()->is("admin/users*") ? "sidebar-nav-active" : "sidebar-nav"); ?>" href="#" onclick="window.openSubNav(this)">
                            <i class="fa-fw fas c-sidebar-nav-icon fa-users">
                            </i>
                            <?php echo e(trans('cruds.userManagement.title')); ?>

                        </a>
                        <ul class="ml-4 subnav hidden">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permission_access')): ?>
                                <li class="items-center">
                                    <a class="<?php echo e(request()->is("admin/permissions*") ? "sidebar-nav-active" : "sidebar-nav"); ?>" href="<?php echo e(route("admin.permissions.index")); ?>">
                                        <i class="fa-fw c-sidebar-nav-icon fas fa-unlock-alt">
                                        </i>
                                        <?php echo e(trans('cruds.permission.title')); ?>

                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role_access')): ?>
                                <li class="items-center">
                                    <a class="<?php echo e(request()->is("admin/roles*") ? "sidebar-nav-active" : "sidebar-nav"); ?>" href="<?php echo e(route("admin.roles.index")); ?>">
                                        <i class="fa-fw c-sidebar-nav-icon fas fa-briefcase">
                                        </i>
                                        <?php echo e(trans('cruds.role.title')); ?>

                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_access')): ?>
                                <li class="items-center">
                                    <a class="<?php echo e(request()->is("admin/users*") ? "sidebar-nav-active" : "sidebar-nav"); ?>" href="<?php echo e(route("admin.users.index")); ?>">
                                        <i class="fa-fw c-sidebar-nav-icon fas fa-user">
                                        </i>
                                        <?php echo e(trans('cruds.user.title')); ?>

                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('project_access')): ?>
                    <li class="items-center">
                        <a class="<?php echo e(request()->is("admin/projects*") ? "sidebar-nav-active" : "sidebar-nav"); ?>" href="<?php echo e(route("admin.projects.index")); ?>">
                            <i class="fa-fw c-sidebar-nav-icon fas fa-project-diagram">
                            </i>
                            <?php echo e(trans('cruds.project.title')); ?>

                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('service_access')): ?>
                    <li class="items-center">
                        <a class="<?php echo e(request()->is("admin/services*") ? "sidebar-nav-active" : "sidebar-nav"); ?>" href="<?php echo e(route("admin.services.index")); ?>">
                            <i class="fa-fw c-sidebar-nav-icon fas fa-gavel">
                            </i>
                            <?php echo e(trans('cruds.service.title')); ?>

                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('blogs_management_access')): ?>
                    <li class="items-center">
                        <a class="has-sub <?php echo e(request()->is("admin/categories*")||request()->is("admin/tags*")||request()->is("admin/posts*") ? "sidebar-nav-active" : "sidebar-nav"); ?>" href="#" onclick="window.openSubNav(this)">
                            <i class="fa-fw fas c-sidebar-nav-icon far fa-file-alt">
                            </i>
                            <?php echo e(trans('cruds.blogsManagement.title')); ?>

                        </a>
                        <ul class="ml-4 subnav hidden">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('category_access')): ?>
                                <li class="items-center">
                                    <a class="<?php echo e(request()->is("admin/categories*") ? "sidebar-nav-active" : "sidebar-nav"); ?>" href="<?php echo e(route("admin.categories.index")); ?>">
                                        <i class="fa-fw c-sidebar-nav-icon far fa-folder-open">
                                        </i>
                                        <?php echo e(trans('cruds.category.title')); ?>

                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('tag_access')): ?>
                                <li class="items-center">
                                    <a class="<?php echo e(request()->is("admin/tags*") ? "sidebar-nav-active" : "sidebar-nav"); ?>" href="<?php echo e(route("admin.tags.index")); ?>">
                                        <i class="fa-fw c-sidebar-nav-icon fas fa-tags">
                                        </i>
                                        <?php echo e(trans('cruds.tag.title')); ?>

                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('post_access')): ?>
                                <li class="items-center">
                                    <a class="<?php echo e(request()->is("admin/posts*") ? "sidebar-nav-active" : "sidebar-nav"); ?>" href="<?php echo e(route("admin.posts.index")); ?>">
                                        <i class="fa-fw c-sidebar-nav-icon fas fa-rss-square">
                                        </i>
                                        <?php echo e(trans('cruds.post.title')); ?>

                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('contact_access')): ?>
                    <li class="items-center">
                        <a class="<?php echo e(request()->is("admin/contacts*") ? "sidebar-nav-active" : "sidebar-nav"); ?>" href="<?php echo e(route("admin.contacts.index")); ?>">
                            <i class="fa-fw c-sidebar-nav-icon far fa-envelope">
                            </i>
                            <?php echo e(trans('cruds.contact.title')); ?>

                        </a>
                    </li>
                <?php endif; ?>

                <?php if(file_exists(app_path('Http/Controllers/Auth/ChangePasswordController.php'))): ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('profile_password_edit')): ?>
                        <li class="items-center">
                            <a href="<?php echo e(route("profile.password.edit")); ?>" class="<?php echo e(request()->is("profile/password") || request()->is("profile/password/*") ? "sidebar-nav-active" : "sidebar-nav"); ?>">
                                <i class="fas fa-cogs"></i>
                                <?php echo e(trans('global.change_password')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                <?php endif; ?>

                <li class="items-center">
                    <a href="#" onclick="event.preventDefault(); document.getElementById('logoutform').submit();" class="sidebar-nav">
                        <i class="fa-fw fas fa-sign-out-alt"></i>
                        <?php echo e(trans('global.logout')); ?>

                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav><?php /**PATH C:\xampp_new\htdocs\yalla wrap it\resources\views/components/sidebar.blade.php ENDPATH**/ ?>