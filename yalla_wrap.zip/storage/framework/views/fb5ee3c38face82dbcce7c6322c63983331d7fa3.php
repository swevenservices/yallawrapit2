<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="card bg-blueGray-100">
        <div class="card-header">
            <div class="card-header-container">
                <h6 class="card-title">
                    <?php echo e(trans('global.edit')); ?>

                    <?php echo e(trans('cruds.service.title_singular')); ?>:
                    <?php echo e(trans('cruds.service.fields.id')); ?>

                    <?php echo e($service->id); ?>

                </h6>
            </div>
        </div>

        <div class="card-body">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('service.edit', [$service])->html();
} elseif ($_instance->childHasBeenRendered('Qo0rRKQ')) {
    $componentId = $_instance->getRenderedChildComponentId('Qo0rRKQ');
    $componentTag = $_instance->getRenderedChildComponentTagName('Qo0rRKQ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Qo0rRKQ');
} else {
    $response = \Livewire\Livewire::mount('service.edit', [$service]);
    $html = $response->html();
    $_instance->logRenderedChild('Qo0rRKQ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_new\htdocs\yalla wrap it\resources\views/admin/service/edit.blade.php ENDPATH**/ ?>