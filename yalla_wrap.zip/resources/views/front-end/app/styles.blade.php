  <!-- Bootstrap Min CSS -->
  <link rel="stylesheet" href="{{ asset('front-end') }}/css/bootstrap.min.css">
  <!-- Animation Min CSS -->
  <link rel="stylesheet" href="{{ asset('front-end') }}/css/animate.min.css">
  <!-- Font Awesome Min CSS -->
  <link  href="{{ asset('front-end') }}/css/fontawesome.min.css">
  <!-- FlatIcon CSS -->
  <link rel="stylesheet" href="{{ asset('front-end') }}/css/flaticon.css">


  <link rel="stylesheet" href="{{ asset('front-end') }}/css/meanmenu.css">

  <!-- Owl Carousel Min CSS -->
  <link rel="stylesheet" href="{{ asset('front-end') }}/css/owl.carousel.min.css">
  <!-- Style CSS -->
  <link rel="stylesheet" href="{{ asset('front-end') }}/css/style.css">
  <!-- Responsive CSS -->
  <link rel="stylesheet" href="{{ asset('front-end') }}/css/responsive.css">
@livewireStyles

  <title>Yalla Wrap It - Best Wrapping services in Uae </title>
  <link rel="icon" type="image/png" href="{{ asset('front-end') }}/img/favicon.png">
