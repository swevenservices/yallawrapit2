<?php

return [
    'site_title' => 'Yalla Warap it',
];
